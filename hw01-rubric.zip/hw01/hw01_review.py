""" Homework 1 Review Week 1 """

def positive():
    """Ask if for an integer via the `input` command.
       Return True if the integer is positive, False otherwise.

    Example test cases:
    % python hw01_review.py
    Enter integer: 1
    True
    % python hw01_review.py
    Enter integer: -1
    False
    % python hw01_review.py
    Enter integer: 0
    True
    """
    "*** YOUR CODE HERE ***"

    """
    Rubric:
    +1 - correct use of input
    +1 - use int() to cast
    +1 - print()
    +0.5 - ran function outside
