test = {
  'name': 'Dog constructor',
  'points': 2,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> dog = Dog('Toby')
          >>> owner = Owner('Alice')
          >>> owner.train_pet()
          'Alice really wants a pet'
          >>> owner.adopt(dog)
          >>> owner.train_pet()
          >>> owner.pet.sit()
          'Toby sits'
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': False,
      'setup': r"""
      >>> from lab06 import *
      """,
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
