test = {
  'name': 'Dog constructor',
  'points': 2,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> dog = Dog('Toby')
          >>> dog.name
          'Toby'
          >>> dog.happiness
          5
          >>> dog.training
          5
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': False,
      'setup': r"""
      >>> from lab06 import *
      """,
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
