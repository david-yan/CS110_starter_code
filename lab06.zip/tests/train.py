test = {
  'name': 'Dog constructor',
  'points': 2,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> dog = Dog('Toby')
          >>> dog.happiness
          5
          >>> dog.training
          5
          >>> dog.train()
          >>> dog.happiness
          4
          >>> dog.training
          6
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': False,
      'setup': r"""
      >>> from lab06 import *
      """,
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
