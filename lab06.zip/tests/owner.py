test = {
  'name': 'Dog constructor',
  'points': 2,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> owner = Owner('Alice')
          >>> owner.name
          'Alice'
          >>> print(owner.pet)
          None
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': False,
      'setup': r"""
      >>> from lab06 import *
      """,
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
