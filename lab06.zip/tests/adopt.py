test = {
  'name': 'Dog constructor',
  'points': 2,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> dog = Dog('Toby')
          >>> owner = Owner('Alice')
          >>> owner.name
          'Alice'
          >>> print(owner.pet)
          None
          >>> owner.adopt(dog)
          >>> owner.pet.name
          'Toby'
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': False,
      'setup': r"""
      >>> from lab06 import *
      """,
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
