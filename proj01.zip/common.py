import json

STORE_FILENAME = 'store'

def read_store():
    """ Reads store items from file. """
    with open(STORE_FILENAME, 'w+') as f:
        raw_data = f.read()
        if raw_data == "":
            return []
        data = json.loads(f.read())
        assert(data.keys() == ['items'])
        return data['items']

def write_store(store_items):
    """ Writes store items to file. """
    with open(STORE_FILENAME, 'w') as f:
        json.dump({'items': store_items}, f)


