import common

def add_item(name, price, store_items):
    """ Adds new item to the store_items list with the given name and price.
        Each item should be stored as a list in the form: [name, price].
        See tests below for examples:

        >>> store_items = []
        >>> add_item('iPhone Galaxy XL', 799.99, store_items)
        >>> print(store_items)
        [['iPhone Galaxy XL', 799.99]]
        >>> add_item('Microsoft Macbook 10', 1299.99, store_items)
        >>> print(store_items)
        [['iPhone Galaxy XL', 799.99], ['Microsoft Macbook 10', 1299.99]]
    """
    "***YOUR CODE HERE***"

def list_items(store_items):
    """ Displays store items in a numbered list in the following format:
        0) <item name>: $<item price>
        1) <item name>: $<item price>
        ...
        See test below for an example.

        >>> store_items = [['iPhone Galaxy XL', 799.99], ['Microsoft Macbook 10', 1299.99]]
        >>> list_items(store_items)
        0) iPhone Galaxy XL: $799.99
        1) Microsoft Macbook 10: $1299.99
    """
    "***YOUR CODE HERE***"

def check_item_index(item_index, store_items):
    """ Checks that the item index is valid.
        Returns:
        - True if index is in bounds of the list, no negative indices!
        - False otherwise

        >>> store_items = [['iPhone Galaxy XL', 799.99], ['Microsoft Macbook 10', 1299.99]]
        >>> check_item_index(0, store_items)
        True
        >>> check_item_index(1, store_items)
        True
        >>> check_item_index(2, store_items)
        False
        >>> check_item_index(-1, store_items)
        False
    """
    "***YOUR CODE HERE***"

def modify_item(item_index, name, price, store_items):
    """ Sets the item in store_items with item_index to have a new name, and price, as
        specified in the arguments.

        >>> store_items = [['iPhone Galaxy XL', 799.99], ['Microsoft Macbook 10', 1299.99]]
        >>> modify_item(0, 'Google S9', 849.99, store_items)
        >>> print(store_items)
        [['Google S9', 849.99], ['Microsoft Macbook 10', 1299.99]]
    """
    "***YOUR CODE HERE***"

def delete_item(item_index, store_items):
    """ Deletes the item in store_items with the specified index.

        >>> store_items = [['iPhone Galaxy XL', 799.99], ['Microsoft Macbook 10', 1299.99]]
        >>> delete_item(1, store_items)
        >>> print(store_items)
        [['iPhone Galaxy XL', 799.99]]
    """
    "***YOUR CODE HERE***"

###############################################################################
########################## DO NOT MODIFY BELOW ################################
###############################################################################

def print_seller_menu():
    print("Here are your options as a seller:")
    print("0) List items")
    print("1) Add item.")
    print("2) Modify existing item.")
    print("3) Delete existing item.")
    print("4) Quit.")

def process_command(command, store_items):
    """ Runs the correct function based on command.
        Returns:
          - True if user chose to quit.
          - False otherwise.
    """
    if command == "0":
        list_items(store_items)
    elif command == "1":
        name = input("Enter item name: ")
        price = float(input("Enter item price: "))
        add_item(name, price, store_items)
    elif command == "2":
        print("Here are you existing items:")
        list_items(store_items)
        item_index = int(input("Which item do you want to modify? "))
        if not check_item_index(item_index, store_items):
            print("Item index is not valid.")
            return False
        name = input("Enter new item name: ")
        price = float(input("Enter new item price: "))
        modify_item(item_index, name, price, store_items)
    elif command == "3":
        print("Here are you existing items:")
        list_items(store_items)
        item_index = int(input("Which item do you want to delete? "))
        if not check_item_index(item_index, store_items):
            print("Item index is not valid.")
            return False
        delete_item(item_index, store_items)
    elif command == "4":
        print("Exiting.")
        return True
    else:
        print("Choice not recognized. Please enter one from the menu.")
    return False

def main():
    # Store items in list.
    # Reads store items from file.
    store_items = common.read_store()

    print("*******************************")
    print("******Welcome to Amazon!*******")
    print("*******************************")

    done = False
    while not done:
        print_seller_menu()
        command = input("Enter the number of your choice: ")
        done = process_command(command, store_items)

    # Writes store items to file.
    common.write_store(store_items)

if __name__ == '__main__':
    main()
