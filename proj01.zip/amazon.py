import common

def main():
    """ The main function that is run. Should continuously print the available choices,
        and ask users for input.

        See the main function in seller.py as an example of how to implement this.
    """
    # Store items in list.
    # Reads store items from file.
    store_items = common.read_store() # DO NOT MODIFY
    cart = []

    print("*******************************")
    print("******Welcome to Amazon!*******")
    print("*******************************")
    ############################## DO NOT MODIFY ABOVE ##############################

    "***YOUR CODE HERE***"

    ############################## DO NOT MODIFY BELOW ##############################
   # Writes store items to file.
    common.write_store(store_items) # DO NOT MODIFY

def display_choices(store_items):
    """ Displays the buyer menu in the following format:
        Add item to cart:
        0) <item name>: $<item price>
        1) <item name>: $<item price>
        ...
        Or:
        N-1) Display cart.
        N) Checkout.
        See test below for example.

        >>> store_items = [['iPhone Galaxy XL', 799.99], ['Microsoft Macbook 10', 1299.99]]
        >>> display_choices(store_items)
        Add item to cart:
        0) iPhone Galaxy XL: $799.99
        1) Microsoft Macboook 10: $1299.99
        Or:
        2) Display cart.
        3) Checkout.
    """
    "***YOUR CODE HERE***"

def check_choice(choice, store_items):
    """ Checks that the choice given is valid.
        Returns:
        - True if the choice is valid. (Remember display cart and checkout options!)
        - False otherwise.

        >>> store_items = [['iPhone Galaxy XL', 799.99], ['Microsoft Macbook 10', 1299.99]]
        >>> check_choice(0, store_items)
        True
        >>> check_choice(1, store_items)
        True
        >>> check_choice(2, store_items)
        True
        >>> check_choice(3, store_items)
        True
        >>> check_choice(4, store_items)
        False
        >>> check_choice(-1, store_items)
        False
    """
    "***YOUR CODE HERE***"

def process_choice(choice, store_items, cart):
    """ Processes the choice, displaying the appropriate information and running the
        appropriate function based on the choice provided.
        Return:
        - True if the user chose the Checkout option.
        - False otherwise.

        See the process_command function in seller.py as an example for this function.
    """
    "***YOUR CODE HERE***"

def add_item_to_cart(item_index, store_items, cart):
    """ Adds the item in store_items with index of item_index to the cart.
        See test below for an example.

        >>> store_items = [['iPhone Galaxy XL', 799.99], ['Microsoft Macbook 10', 1299.99]]
        >>> cart = []
        >>> add_item_to_cart(1, store_items, cart)
        >>> print(cart)
        [['Microsoft Macbook 10', 1299.99]]
        >>> add_item_to_cart(0, store_items, cart)
        >>> print(cart)
        [['Microsoft Macbook 10', 1299.99], ['iPhone Galaxy XL', 799.99]]
        >>> add_item_to_cart(1, store_items, cart)
        >>> print(cart)
        [['Microsoft Macbook 10', 1299.99], ['iPhone Galaxy XL', 799.99], ['Microsoft Macbook 10', 1299.99]]
    """
    "***YOUR CODE HERE***"

def display_cart(cart):
    """ Displays the cart in the following format:
        <item name>: $<item price>
        <item name>: $<item price>
        ...
        Total price: $<total price>

        >>> cart = [['item 1', 1099.99], ['item 2', 799.99], ['item 3', 1299.99]]
        >>> display_cart(cart)
        item1: $1099.99
        item2: $799.99
        item3: $1299.99
        Total price: $3,199.97
    """
    "***YOUR CODE HERE***"

def checkout(cart):
    """ Displays the cart, then prints a Goodbye message in the following format:
        Here are the items you purchased:
        <item name>: $<item price>
        <item name>: $<item price>
        ...
        Total price: $<total price>
        Thank you! Have a great day! No returns!

        >>> cart = [['item 1', 1099.99], ['item 2', 799.99], ['item 3', 1299.99]]
        >>> checkout(cart)
        Here are the items you just purchased:
        item1: $1099.99
        item2: $799.99
        item3: $1299.99
        Total price: $3,199.97
        Thank you! Have a great day! No returns!
    """
    "***YOUR CODE HERE***"

###############################################################################
########################## DO NOT MODIFY BELOW ################################
###############################################################################

if __name__ == '__main__':
    main()
