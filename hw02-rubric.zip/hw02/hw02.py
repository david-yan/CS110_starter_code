""" Homework 2: Loops, Functions """

def reverse(string):
    """ Reverse a string without using the reversed string function.

    >>> reverse('abc')
    'cba'
    >>> reverse('a')
    'a'
    >>> reverse('')
    ''
    """

    """
    Rubric
    +1 - Correct for loop
    +1 - Correct output
    """

    output = ""
    for ____:
        output += ____
    return output

def palindrome(string):
    """ Returns True if string is a palindrome.
        * Hint: Use the reverse function you wrote above.

    >>> palindrome('aba')
    True
    >>> palindrome('detartrated')
    True
    >>> palindrome('abc')
    False
    >>> palindrome('')
    True
    """

    """
    Rubric
    +1 - Correct
    """

    return ____ == ____

def every_other(lst, n):
    """ Returns the result of combining every nth item of lst.

    >>> every_other([1, 2, 3, 4, 5, 6], 2)
    [1, 3, 5]
    >>> every_other([1, 2, 3, 4, 5], 2)
    [1, 3, 5]
    >>> every_other([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 3)
    [1, 4, 7, 10]
    """

    """
    Rubric
    +0.5 - Used for loop
    +1 - Correct range
    +1 - Correct output
    """

    output = []
    "*** YOUR CODE HERE ***"
    return output
