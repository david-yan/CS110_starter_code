def two_of_three(x, y, z):
    """Return a*a + b*b, where a and b are the two smallest members of the
    positive numbers x, y, and z.

    >>> two_of_three(1, 2, 3)
    5
    >>> two_of_three(5, 3, 1)
    10
    >>> two_of_three(10, 2, 8)
    68
    >>> two_of_three(5, 5, 5)
    50
    """
    "*** YOUR CODE HERE ***"

def second_largest(lst):
    """Returns the second largest number in lst.
    >>> second_largest([2, 1])
    1
    >>> second_largest([1, 2, 3, 4, 5])
    4
    >>> second_largest([3, 5, 2, 6, 1])
    5
    >>> second_largest([5, 2, 3, 4, 5])
    5
    """
    "*** YOUR CODE HERE ***"

def num_sevens(x):
    """Returns the number of times 7 appears as a digit of x.

    >>> num_sevens(3)
    0
    >>> num_sevens(7)
    1
    >>> num_sevens(7777777)
    7
    >>> num_sevens(2637)
    1
    >>> num_sevens(76370)
    2
    >>> num_sevens(12345)
    0
    """
    "*** YOUR CODE HERE ***"
