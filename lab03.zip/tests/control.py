test = {
  'name': 'Control',
  'points': 0,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> True or False and 1 / 0
          dd16f745980ddbb2536e844eab25216e
          # locked
          >>> False and (not False or (False or 1 / 0) and True)
          2d9b08294613331e440b44486422c4a8
          # locked
          >>> not(not(False and not(True and (not True or not False) or not False and True)))
          2d9b08294613331e440b44486422c4a8
          # locked
          """,
          'hidden': False,
          'locked': True
        },
        {
          'code': r"""
          >>> def follow_me(follow, me):
          ...   if follow == me:
          ...       follow += me
          ...       if follow < 0:
          ...           return follow - me
          ...       elif me % 2 == 0:
          ...           me += 5
          ...   elif follow > me:
          ...       me -= follow
          ...       follow += me
          ...       if follow < 0:
          ...           return me * 100 + follow
          ...   if me % 2 == 0:
          ...       return me // 2 + follow * 3
          ...   else:
          ...       return follow + me
          ...   return me
          >>> follow_me(27, 10)
          5a06f954a796886cdfe6ec769cd69241
          # locked
          >>> follow_me(0, -20)
          e8c8cb888a96c63c6a42531f690ee603
          # locked
          >>> follow_me(10, 10)
          fea5eeea71fe1b62d26653764947afdf
          # locked
          >>> follow_me(-1, -1)
          2e89b646c165ef9bc90414797aa89772
          # locked
          """,
          'hidden': False,
          'locked': True
        },
        {
          'code': r"""
          >>> def till_when(when):
          ...   while(1 / when < 1):
          ...       if when % 2 == 0:
          ...           when /= 2
          ...       else:
          ...           when = 3 * when - 1
          ...   return when
          >>> till_when(10) # If this errors, just type Error.
          08f24971052c86eff8b4427cca829fbf
          # locked
          >>> till_when(13) # If this errors, just type Error.
          08f24971052c86eff8b4427cca829fbf
          # locked
          >>> till_when(18) # If this errors, just type Error.
          6b3db523f17adbf1e2e542494109c860
          # locked
          """,
          'hidden': False,
          'locked': True
        }
      ],
      'scored': False,
      'type': 'wwpp'
    }
  ]
}
