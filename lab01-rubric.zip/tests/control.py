test = {
  'name': 'Control',
  'points': 0,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> def xk(c, d):
          ...     if c == 4:
          ...         return 6
          ...     elif d >= 4:
          ...         return 6 + 7 + c
          ...     else:
          ...         return 25
          >>> xk(10, 10)
          a799615418a6f4501ad544e13806a562
          # locked
          >>> xk(10, 6)
          a799615418a6f4501ad544e13806a562
          # locked
          >>> xk(4, 6)
          dec12663f9c55de3a6af4f37f7906f7d
          # locked
          >>> xk(0, 0)
          56eec9fe30bee046d0f7ad12b7ef6710
          # locked
          """,
          'hidden': False,
          'locked': True    # +1 locked is False, and answers above are not encrypted.
        },
        {
          'code': r"""
          >>> def how_big(x):
          ...     if x > 10:
          ...         print('huge')
          ...     elif x > 5:
          ...         return 'big'
          ...     elif x > 0:
          ...         print('small')
          ...     else:
          ...         print("nothin'")
          >>> how_big(7)
          ea48d3d366199a740e108b03eab5e4fd
          # locked
          >>> how_big(12)
          b7007cebe6ac123a7da77f9ad1657c74
          # locked
          >>> how_big(1)
          d9a1a72f00afa1bef92f4614b029c1e1
          # locked
          >>> how_big(-1)
          fb00613825377dc868cb11b746d59c1c
          # locked
          """,
          'hidden': False,
          'locked': True    # +1 locked is False, and answers above are not encrypted.
        }
      ],
      'scored': False,
      'type': 'wwpp'
    }
  ]
}
