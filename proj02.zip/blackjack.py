"""CS110-02 Presents Blackjack."""
"""***DO NOT MODIFY THIS FILE***"""

from game import Game

def play_game(args):
    game = Game(args.players, args.chips, args.decks)
    game.play_game()

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description="Play Blackjack")
    parser.add_argument('--decks', '-d', nargs='?', type=int,
                        default=7, help='How many decks to shuffle in')
    parser.add_argument('--players', '-p', nargs='?', type=int,
                        default=1, help='Number of players in the game')
    parser.add_argument('--chips', '-c', nargs='?', type=int,
                        default=100, help='Number of starting chips')

    args = parser.parse_args()
    play_game(args)
