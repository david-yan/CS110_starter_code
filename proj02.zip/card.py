"""Functions that simulate drawing from a deck.

Drawing a card does not draw from a random integer, but rather draws from a
simulated shuffled deck, or a number of shuffled decks. After the deck(s) run
out, the cards will be reshuffled.
"""

from random import shuffle

class Decks:
    def __init__(self, num_decks=1):
        self.num_decks = num_decks
        self.cards = list(range(52)) * num_decks
        self.index = 0
        self.num_cards = 52 * num_decks
        self.shuffle_cards()

    def shuffle_cards(self):
        self.index = 0
        shuffle(self.cards)

    def draw(self):
        self.index += 1
        if self.index == self.num_cards:
            self.shuffle_cards()
        return Card(self.cards[self.index-1])

values = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K']
suits = ['S', 'C', 'H', 'D']

class Card:
    def __init__(self, num):
        self.suit = suits[num // 13]
        self.value = num % 13

    def string(self):
        return '{0}{1}'.format(values[self.value], self.suit)
