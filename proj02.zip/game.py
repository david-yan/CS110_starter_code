"""Functions that simulate the game."""

from card import Card, Decks
from player import Player
import math

class Game:
    # Attributes:
    # - self.players: A list of the players
    # - self.total_players: Number of players left in the game
    # - self.dealer: The dealer
    # - self.deck: The collection of shuffled decks

    def __init__(self, num_players, num_chips, num_decks):
        """ Initializes a game with the specified number of players, each
            starting with the specified number of chips and with a name between
            the numbers of 1 to num_players, and a deck of cards made up of the
            specified number of decks.

            >>> game = Game(3, 200, 7)
            >>> assert(len(game.players) == 3, 'Incorrect number of players')
            >>> for i in range(len(game.players)):
            ...   player = game.players[i]
            ...   assert(player.name == str(i + 1), 'Incorrect name')
            ...   assert(player.chips == 200, 'Incorrect number of chips')
        """
        """***YOUR CODE HERE***"""

    def deal_cards(self):
        """ Deal two cards to all players in the game, including the dealer.

            >>> game = Game(1, 10, 1)
            >>> game.deck = TestDeck([Card(i) for i in range(4)])
            >>> assert len(game.players[0].cards) == 0, 'Player cards should start out empty'
            >>> assert len(game.dealer.cards) == 0, 'Player cards should start out empty'
            >>> game.deal_cards()
            Player 1 receives AS
            Player 1 receives 2S
            Player dealer receives 3S
            Player dealer receives 4S
            >>> for i in range(len(game.players)):
            ...   player = game.players[i]
            ...   assert len(player.cards) == 2, 'Player cards should receive 2 cards'
            >>> assert len(game.dealer.cards) == 2, 'Dealer should receive 2 cards'
        """
        """***YOUR CODE HERE***"""

    def finish_round(self):
        """ Finishes the round.
            1. For each player that has a higher card total compared to the dealer,
               award the player its wager.
               For those that have a lower card total, or have gone bust, reduce
               that player's chip count by its wager.
            2. Reset each player. (use the player.reset() function)

            >>> game = Game(2, 10, 1)
            >>> game.deck = TestDeck([Card(i) for i in [1, 2, 0, 10, 10, 11]])
            >>> game.players[0].wager = 5
            >>> game.players[1].wager = 5
            >>> game.deal_cards()
            Player 1 receives 2S
            Player 1 receives 3S
            Player 2 receives AS
            Player 2 receives JS
            Player dealer receives JS
            Player dealer receives QS
            >>> game.finish_round()
            Player 1 lost 5 chips. New chip total: 5
            Player 2 won 5 chips! New chip total: 15
        """
        """***YOUR CODE HERE***"""

    def check_chip_counts(self):
        """ Check the chip counts of all the players.
            Players with no chips should be removed from the game.

            >>> game = Game(2, 10, 1)
            >>> game.players[1].chips = 0
            >>> game.check_chip_counts()
            >>> assert len(game.players) == 1, 'There should only be 1 player left'
            >>> assert game.players[0].name == '1', 'Player 1 should be left'
        """
        """***YOUR CODE HERE***"""

    def play_game(self):
        """ Plays the game.
            - While there are still players remaining:
              1. Start a round by dealing cards.
              2. For each player, play out their turn.
              3. Play out the dealer's turn.
              4. Finish the round and award chip winnings/losses.
              5. Remove any players that have gone broke.
        """
        """***YOUR CODE HERE***"""


