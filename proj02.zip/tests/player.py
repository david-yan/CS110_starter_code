test = {
  'name': 'Player',
  'points': 2,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> player = Player('player', 100)
          >>> player.name
          'player'
          >>> player.chips
          100
          >>> player.cards
          []
          >>> player.card_total
          0
          >>> player.wager
          0
          >>> player.num_aces
          0
          >>> player.reduced_aces
          0
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': False,
      'setup': r"""
      >>> from player import *
      """,
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
