test = {
  'name': 'Game',
  'points': 2,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> game = Game(2, 10, 1)
          >>> game.deck = TestDeck([Card(i) for i in [1, 2, 0, 10, 10, 11]])
          >>> game.players[0].wager = 5
          >>> game.players[1].wager = 5
          >>> game.deal_cards()
          Player 1 receives 2S
          Player 1 receives 3S
          Player 2 receives AS
          Player 2 receives JS
          Player dealer receives JS
          Player dealer receives QS
          >>> game.finish_round()
          Player 1 lost 5 chips. New chip total: 5
          Player 2 won 5 chips! New chip total: 15
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': False,
      'setup': r"""
      >>> from game import *
      >>> from card import Card
      >>> from tests.helpers import TestDeck
      """,
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
