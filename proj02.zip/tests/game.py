test = {
  'name': 'Game',
  'points': 2,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> game = Game(3, 200, 7)
          >>> assert len(game.players) == 3, 'Incorrect number of players'
          >>> assert game.total_players == 3, 'Incorrect number of total_players'
          >>> for i in range(len(game.players)):
          ...   player = game.players[i]
          ...   assert player.name == str(i + 1), 'Incorrect name'
          ...   assert player.chips == 200, 'Incorrect number of chips'
          >>> assert game.deck.num_decks == 7, 'Incorrect number of decks'
          >>> assert game.deck.index == 0, 'Deck should start unused. Incorrect index'
          >>> assert isinstance(game.dealer, Player), 'Incorrect class for Dealer'
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> game1 = Game(2, 10, 2)
          >>> game2 = Game(4, 15, 3)
          >>> players1 = game1.players
          >>> players2 = game2.players
          >>> assert len(game1.players) == 2, 'Incorrect number of players'
          >>> assert game1.total_players == 2, 'Incorrect number of total_players'
          >>> assert len(game2.players) == 4, 'Incorrect number of players'
          >>> assert game2.total_players == 4, 'Incorrect number of total_players'
          >>> assert game1.players[0] is not game1.players[1]
          >>> assert game1.players[0] is not game2.players[0]
          >>> assert game1.deck is not game2.deck
          >>> assert game1.dealer is not game2.dealer
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': False,
      'setup': r"""
      >>> from player import *
      >>> from game import *
      """,
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
