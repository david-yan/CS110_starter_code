def test_input(expected_msg, output_msgs):
  output_iter = iter(output_msgs)
  def input_func(msg):
    assert msg == expected_msg, 'The input message doesn\'t match the expected message. Expected: {}'.format(expected_msg)
    return next(output_iter)
  return input_func


class TestDeck:
  def __init__(self, cards):
    self.card_iter = iter(cards)

  def draw(self):
    return next(self.card_iter)
