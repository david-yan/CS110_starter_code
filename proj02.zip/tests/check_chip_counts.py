test = {
  'name': 'check_chip_counts',
  'points': 2,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> game = Game(2, 10, 1)
          >>> game.players[1].chips = 0
          >>> game.check_chip_counts()
          >>> assert len(game.players) == 1, 'There should only be 1 player left'
          >>> assert game.players[0].name == '1', 'Player 1 should be left'
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': False,
      'setup': r"""
      >>> from game import *
      """,
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
