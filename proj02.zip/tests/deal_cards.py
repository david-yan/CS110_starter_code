test = {
  'name': 'Game',
  'points': 2,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> game = Game(1, 10, 1)
          >>> game.deck = TestDeck([Card(i) for i in range(4)])
          >>> assert len(game.players[0].cards) == 0, 'Player cards should start out empty'
          >>> assert len(game.dealer.cards) == 0, 'Player cards should start out empty'
          >>> game.deal_cards()
          Player 1 receives AS
          Player 1 receives 2S
          Player dealer receives 3S
          Player dealer receives 4S
          >>> for i in range(len(game.players)):
          ...   player = game.players[i]
          ...   assert len(player.cards) == 2, 'Player cards should receive 2 cards'
          >>> assert len(game.dealer.cards) == 2, 'Dealer should receive 2 cards'
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': False,
      'setup': r"""
      >>> from game import *
      >>> from card import Card
      >>> from tests.helpers import TestDeck
      """,
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
