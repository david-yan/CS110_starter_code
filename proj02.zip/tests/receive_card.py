test = {
  'name': 'Place wager',
  'points': 2,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> player = Player('1', 100)
          >>> player.card_total
          0
          >>> ace = Card(0)
          >>> player.receive_card(ace)
          Player 1 receives AS
          >>> player.card_total
          11
          >>> player.num_aces
          1
          >>> player.reduced_aces
          0
          >>> player.receive_card(ace)
          Player 1 receives AS
          >>> player.card_total
          12
          >>> player.num_aces
          2
          >>> player.reduced_aces
          1
          >>> queen = Card(11)
          >>> player.receive_card(queen)
          Player 1 receives QS
          >>> player.card_total
          12
          >>> player.num_aces
          2
          >>> player.reduced_aces
          2
          >>> player.receive_card(queen)
          Player 1 receives QS
          >>> player.card_total
          22
          >>> player.num_aces
          2
          >>> player.reduced_aces
          2
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': False,
      'setup': r"""
      >>> from player import *
      >>> from card import *
      """,
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
