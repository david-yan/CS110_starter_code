test = {
  'name': 'Place wager',
  'points': 2,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> player = Player('1', 100)
          >>> expected_msg = '0) Hit\n1) Stand\n'
          >>> queen = Card(11)
          >>> ace = Card(0)
          >>> player.receive_card(queen)
          Player 1 receives QS
          >>> player.receive_card(queen)
          Player 1 receives QS
          >>> test_deck = TestDeck([ace, ace])
          >>> player.do_turn(test_deck, input_func=test_input(expected_msg, ['0', '0']))
          Player 1's turn!
          Player 1's chip count: 100
          Player 1's cards: QS QS
          Total: 20
          Player 1 receives AS
          Player 1's cards: QS QS AS
          Total: 21
          Player 1 receives AS
          Bust!
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': False,
      'setup': r"""
      >>> from player import *
      >>> from card import *
      >>> from tests.helpers import test_input, TestDeck
      """,
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
