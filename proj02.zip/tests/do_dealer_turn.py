test = {
  'name': 'do_dealer_turn',
  'points': 2,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> dealer = Player('dealer', 100)
          >>> expected_msg = '0) Hit\n1) Stand\n'
          >>> test_deck = TestDeck([Card(9), Card(7)])
          >>> dealer.do_dealer_turn(test_deck)
          Doing dealer's turn.
          Player dealer's cards:
          Total: 0
          Player dealer receives 10S
          Player dealer's cards: 10S
          Total: 10
          Player dealer receives 8S
          Player dealer's cards: 10S 8S
          Total: 18
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': False,
      'setup': r"""
      >>> from player import *
      >>> from card import *
      >>> from tests.helpers import test_input, TestDeck
      """,
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
