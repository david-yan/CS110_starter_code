test = {
  'name': 'Place wager',
  'points': 2,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> player = Player('1', 100)
          >>> expected_msg = 'How much would you like to wager? '
          >>> player.place_wager(input_func=test_input(expected_msg, ['101', '50']))
          Player 1's chip count: 100
          Not enough chips.
          Player 1's chip count: 100
          >>> assert player.wager == 50, 'Player\' wager should be 50, but is {}'.format(player.wager)
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': False,
      'setup': r"""
      >>> from player import *
      >>> from tests.helpers import test_input
      """,
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
