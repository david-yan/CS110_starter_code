test = {
  'name': 'Place wager',
  'points': 2,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> player = Player('1', 100)
          >>> expected_msg = 'How much would you like to wager? '
          >>> player.place_wager(input_func=test_input(expected_msg, ['50']))
          Player 1's chip count: 100
          >>> player.win_chips()
          Player 1 won 50 chips! New chip total: 150
          >>> player.chips
          150
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': False,
      'setup': r"""
      >>> from player import *
      >>> from tests.helpers import test_input
      """,
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
