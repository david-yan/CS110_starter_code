"""Functions for players."""

class Player:
    # Attributes:
    # - self.name: Player's name
    # - self.chips: Player's chip total
    # - self.cards: List of cards in player's hand
    # - self.card_total: The player's card total (over 21 is bust)
    # - self.wager: Player's wager
    # - self.num_aces: The number of aces that the player has received
    # - self.reduced_aces: The number of aces that have been reduced in value

    def __init__(self, name, chips):
        """ Initializes a player with the specified name and chip total.
            Additionally:
            - The player should have no cards in his or hand.
            - The player should have no wager.

            >>> player = Player('player', 100)
            >>> player.name
            'player'
            >>> player.chips
            100
            >>> player.cards
            []
            >>> player.card_total
            0
            >>> player.wager
            0
            >>> player.num_aces
            0
            >>> player.reduced_aces
            0
        """
        """***YOUR CODE HERE***"""

    def place_wager(self, input_func=input):
        """ Requests the player to place a wager.
            1. Print the player's chip count in the form:
               'Player <name>\'s chip count: <chip count>'
            2. Asks the player to place a wager with the `input_func()` function, and the
               message 'How much would you like to wager?'.

               **NOTE**
               You'll notice that one of the arguments to this function is `input_func=input`.
               This sets the `input_func` variable to the `input()` function. This is here
               for testing purposes. Please use `input_func()` in place of where you would
               normally put `input()`.

            3. Check to see that the player has enough chips to place their wager. If not,
               print 'Not enough chips.', and repeat step 2.
            4. Set the player's wager to the specified wager.

            >>> player = Player('1', 100)
            >>> player.place_wager()
            Player 1's chip count: 100
            How much would you like to wager? 101
            Not enough chips.
            How much would you like to wager? 100
            >>> player.wager
            100
        """
        """***YOUR CODE HERE***"""

    def win_chips(self):
        """ Gives chips to the player equal to their wager.
            Also prints:
            'Player <name> won <wager> chips! New chip total: <chip total>'

            >>> player = Player('1', 100)
            >>> player.place_wager()
            Player 1's chip count: 100
            How much would you like to wager? 50
            >>> player.win_chips()
            Player 1 won 50 chips! New chip total: 150
            >>> player.chips
            150
        """
        """***YOUR CODE HERE***"""

    def lose_chips(self):
        """ Takes chips from the player equal to their wager.
            Also prints:
            'Player <name> lost <wager> chips. New chip total: <chip total>'

            >>> player = Player('1', 100)
            >>> player.place_wager()
            Player 1's chip count: 100
            How much would you like to wager? 50
            >>> player.lose_chips()
            Player 1 lost 50 chips. New chip total: 50
            >>> player.chips
            50
        """
        """***YOUR CODE HERE***"""

    def receive_card(self, card):
        """ Receives a card.
            1. Print:
               'Player <name> receives <card.string()>.'
            2. Adds the card to the player's hand.
            3. Updates the player's card total.
              - If the player's card is an ace, add 11 to the card total, and increment num_aces.
            4. If the player goes bust, and the player has aces that can be reduced in value
               from 11 to 1, reduce an ace and increment the number of reduced aces.

            >>> player = Player('1', 100)
            >>> player.card_total
            0
            >>> ace = Card(0)
            >>> player.receive_card(ace)
            Player 1 receives AS
            >>> player.card_total
            11
            >>> player.num_aces
            1
            >>> player.reduced_aces
            0
            >>> player.receive_card(ace)
            Player 1 receives AS
            >>> player.card_total
            12
            >>> player.num_aces
            2
            >>> player.reduced_aces
            1
            >>> queen = Card(11)
            >>> player.receive_card(queen)
            Player 1 receives QS
            >>> player.card_total
            12
            >>> player.num_aces
            2
            >>> player.reduced_aces
            2
            >>> player.receive_card(queen)
            Player 1 receives QS
            >>> player.card_total
            22
            >>> player.num_aces
            2
            >>> player.reduced_aces
            2
        """
        """***YOUR CODE HERE***"""

    def do_turn(self, deck, input_func=input):
        """ Does the player's turn.
            1. Immediately prints:
               'Player <name>\'s turn!'
            2. While the player has not chosen to stand, or gone bust:
              - Display the player's cards and card total (use `display_cards()`).
              - Give the player the chance to hit or stand.
              - If the player chooses to hit, then the player should receive a new card.
              - If the player goes bust from receiving a new card, print 'Bust!'

            Example test:
            >>> player = Player('1', 100)
            >>> queen = Card(11)
            >>> player.receive_card(queen)
            Player 1 receives QS
            >>> player.receive_card(queen)
            Player 1 receives QS
            >>> player.do_turn(deck)
            Player 1's turn!
            Player 1's cards: QS QS
            Total: 20
            0) Hit
            1) Stand
            0
            Player 1 receives AS
            Player 1's cards: QS QS AS
            Total: 21
            0) Hit
            1) Stand
            0
            Player 1 receives AS
            Player 1's cards: QS QS AS
            Bust!
        """
        """***YOUR CODE HERE***"""

    def do_dealer_turn(self, deck):
        """ Do the dealer's turn automatically.
            The dealer will choose to hit if his card total is below 18.
            1. Print:
               'Doing dealer's turn.'
            2. Display the dealer's cards.
            3. While the dealer's card total is below 18:
               - Dealer receives a new card.
               - Display the dealer's new cards.
            4. If the dealer busts, print 'Bust!'

            Example test:
            >>> dealer = Player('dealer', 0)
            >>> dealer.do_dealer_turn(deck)
            Doing dealer's turn.
            Player dealer's cards:
            Total: 0
            Player dealer receives 10S
            Player dealer's cards: 10S
            Total: 10
            Player dealer receives 8S
            Player dealer's cards: 10S 8S
            Total: 18
        """

    ###########################################################################
    ########################### Methods given #################################
    ###########################################################################

    def display_cards(self):
        """ Display cards and card total. """
        output = "Player {}\'s cards:".format(self.name)
        for card in self.cards:
            output += " " + card.string()
        print(output)
        print("Total: {}".format(self.card_total))

    def reset(self):
        """ Resets the player for a new round. """
        self.wager = 0
        self.cards = []
        self.card_total = 0
        self.num_aces = 0
        self.reduced_aces = 0

