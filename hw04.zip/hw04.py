def error_handler(string, num):
    """Tries the following:
    1. Converts the `string` parameter to an int.
    2. Divide the converted `string` with `num` and print the result

    - If the cast fails, print 'Cannot cast to int'
    - If the division causes an error, print 'Division failed'
    - If no error happens, print 'No errors'
    - At the very end, print 'Finished'

    >>> error_handler('not an int', 2)
    Cannot cast to int
    Finished
    >>> error_handler('1', 0)
    Division failed
    Finished
    >>> error_handler('1', 2)
    0.5
    No errors
    Finished
    """
