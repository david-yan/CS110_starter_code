import tempfile
import os

def prepare_test_files():
    f = tempfile.NamedTemporaryFile(mode='wt', delete=False)
    f.write(f.name)
    return f.name

def cleanup(filename):
    os.remove(filename)
