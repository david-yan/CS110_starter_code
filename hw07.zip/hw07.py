class Dog:
    def __init__(___):
        """Write the constructor for the Dog class. Each dog should be
        initialized with a name that is provided, and an age that starts
        at 0.

        All attributes should be private.

        The function parameters have not been provided.
        Be sure to add the appropriate arguments to the function.

        >>> dog = Dog('Toby')
        """
        "*** YOUR CODE HERE ***"

    def get_name(___):
        """Write the getter instance function for the name of the dog.

        Returns the name of the dog.

        The function parameters have not been provided this time. Be sure to
        add the appropriate arguments to the function.

        >>> dog = Dog('Toby')
        >>> dog.get_name()
        'Toby'
        """
        "*** YOUR CODE HERE ***"

    def get_age(___):
        """Write the getter instance function for the age of the dog.

        Returns the age of the dog.

        The function parameters have not been provided this time. Be sure to
        add the appropriate arguments to the function.

        >>> dog = Dog('Toby')
        >>> dog.get_age()
        0
        """
        "*** YOUR CODE HERE ***"

    def increase_age(___):
        """Increase the age of the dog by 1.

        Returns nothing.

        The function parameters have not been provided this time. Be sure to
        add the appropriate arguments to the function.

        >>> dog = Dog('Toby')
        >>> dog.get_age()
        0
        >>> dog.increase_age()
        >>> dog.get_age()
        1
        """
        "*** YOUR CODE HERE ***"


    def get_size(___):
        """Get the size of the dog based on its age.
        - If the dog is between the ages of 0 <= age < 2, the dog is
          considered to be `small`.
        - If the dog is between the ages of 2 <= age < 4, the dog is
          considered to be 'medium'.
        - If the dog is age >= 4, the dog is considered to be 'large'.
        **Not accurate with real life dogs.

        Returns the size of the dog.

        The function parameters have not been provided this time. Be sure to
        add the appropriate arguments to the function.

        >>> dog = Dog('Toby')
        >>> dog.get_size()
        'small'
        >>> dog.increase_age()
        >>> dog.get_size()
        'small'
        >>> dog.increase_age()
        >>> dog.get_size()
        'medium'
        >>> dog.increase_age()
        >>> dog.get_size()
        'medium'
        >>> dog.increase_age()
        >>> dog.get_size()
        'large'
        """
        "*** YOUR CODE HERE ***"

