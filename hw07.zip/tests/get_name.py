test = {
  'name': 'Constructor',
  'points': 2,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> dog = Dog('Toby')
          >>> dog.get_name()
          'Toby'
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': False,
      'setup': r"""
      >>> from hw07 import *
      """,
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
