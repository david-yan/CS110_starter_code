test = {
  'name': 'Constructor',
  'points': 2,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> dog = Dog('Toby', 'medium', 'labrador')
          >>> dog.get_size()
          'medium'
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': False,
      'setup': r"""
      >>> from hw06 import *
      """,
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
