class Dog:
    def <constructor>():
        """Write the constructor for the Dog class. Each dog should be
        initialized with the name, size, and breed attributes.

        The function name and function parameters have not been provided this
        time. Be sure to rename the function, and add the appropriate arguments
        to the function.

        >>> dog = Dog('Toby', 'medium', 'labrador')
        >>> dog.name
        'Toby'
        >>> dog.size
        'medium'
        >>> dog.breed
        'labrador'
        """
        "*** YOUR CODE HERE ***"

    def get_name():
        """Write the getter instance function for the name of the dog.

        Returns the name of the dog.

        The function parameters have not been provided this time. Be sure to
        add the appropriate arguments to the function.

        >>> dog = Dog('Toby', 'medium', 'labrador')
        >>> dog.get_name()
        'Toby'
        """
        "*** YOUR CODE HERE ***"

    def get_size():
        """Write the getter instance function for the size of the dog.

        Returns the size of the dog.

        The function parameters have not been provided this time. Be sure to
        add the appropriate arguments to the function.

        >>> dog = Dog('Toby', 'medium', 'labrador')
        >>> dog.get_size()
        'medium'
        """
        "*** YOUR CODE HERE ***"

    def get_breed():
        """Write the getter instance function for the breed of the dog.

        Returns the breed of the dog.

        The function parameters have not been provided this time. Be sure to
        add the appropriate arguments to the function.

        >>> dog = Dog('Toby', 'medium', 'labrador')
        >>> dog.get_breed()
        'labrador'
        """
        "*** YOUR CODE HERE ***"

