"""Functions that simulate drawing from a deck.

Drawing a card does not draw from a random integer, but rather draws from a
simulated shuffled deck, or a number of shuffled decks. After the deck(s) run
out, the cards will be reshuffled.
"""

from random import shuffle

values = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K']
suits = ['S', 'C', 'H', 'D']

class Card:
    # Attributes:
    # - self.__suit: Card suit (number between [0, 3])
    # - self.__value: Card value (number between [0, 12])

    def __init__(self, num):
        """Initializes a card with the specified `num`
           - The suit is `num // 13`
           - The value is `num % 13`
        """
        pass # Be sure to remove me!

    def string(self):
        """ Provided. """
        return '{0}{1}'.format(values[self.value], self.suit)

class Decks:
    # Attributes:
    # - self.__num_decks: The number of decks in this collection
    # - self.__cards: The list of the cards in shuffled order
    # - self.__index: Where in the list of cards we've drawn to

    def __init__(self, num_decks):
        """Initializes a set with a `num_decks` number of decks.
           Shuffles all of the decks together after initializing.
        """
        pass # Be sure to remove me!

    def shuffle_cards(self):
        """Shuffles all of the cards, and resets the index to be at the
           beginning of the list.

           **HINT**: Use the shuffle() function.
        """
        pass # Be sure to remove me!

    def draw(self):
        """Draw and return a card from the deck.
           - Advance the index by 1
           - If the index is at the end of all cards, reshuffle the cards
           - Return the drawn card
        """
        pass # Be sure to remove me!

