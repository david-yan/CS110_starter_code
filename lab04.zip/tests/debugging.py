test = {
  'name': 'debugging-quiz',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'answer': '2dabe3bf41b5a2def981a9d81acbcac9',
          'choices': [
            'f("hi")',
            'g(x + x, x)',
            'h(x + y * 5)'
          ],
          'hidden': False,
          'locked': True,
          'question': r"""
          In the following traceback, what is the most recent function call?
          Traceback (most recent call last):
              File "temp.py", line 10, in <module>
                f("hi")
              File "temp.py", line 2, in f
                return g(x + x, x)
              File "temp.py", line 5, in g
                return h(x + y * 5)
              File "temp.py", line 8, in h
                return x + 0
            TypeError: must be str, not int
          """
        },
        {
          'answer': 'ad625244b1cb04dcd355659df2a67c30',
          'choices': [
            'line 10',
            'line 2',
            'line 5',
            'line 8'
          ],
          'hidden': False,
          'locked': True,
          'question': r"""
          In the following traceback, which line caused the error?
          Traceback (most recent call last):
              File "temp.py", line 10, in <module>
                f("hi")
              File "temp.py", line 2, in f
                return g(x + x, x)
              File "temp.py", line 5, in g
                return h(x + y * 5)
              File "temp.py", line 8, in h
                return x + 0
            TypeError: must be str, not int
          """
        },
        {
          'answer': '020e452a94b2d2347bf98f8857c9c626',
          'choices': [
            'the code attempted to add a string to an integer',
            'the code looped infinitely',
            'there was a missing return statement'
          ],
          'hidden': False,
          'locked': True,
          'question': r"""
          In the following traceback, what is the cause of this error?
          Traceback (most recent call last):
              File "temp.py", line 10, in <module>
                f("hi")
              File "temp.py", line 2, in f
                return g(x + x, x)
              File "temp.py", line 5, in g
                return h(x + y * 5)
              File "temp.py", line 8, in h
                return x + 0
            TypeError: must be str, not int
          """
        },
        {
          'answer': '296eacbd4b91838f7d22bd89182962bc',
          'choices': [
            'For permanant debugging so you can have long term confidence in your code',
            'To ensure that certain conditions are true at certain points in your code',
            'To investigate the values of variables at certain points in your code'
          ],
          'hidden': False,
          'locked': True,
          'question': 'When should you use print statements?'
        },
        {
          'answer': 'd38292bb087ffa167124f4986969afc5',
          'choices': [
            "You don't need to do anything, ok only looks at returned values, not printed values",
            "Print with 'DEBUG:' at the front of the outputted line",
            'Print with # at the front of the outputted line'
          ],
          'hidden': False,
          'locked': True,
          'question': 'How do you prevent the ok autograder from interpreting print statements as output?'
        },
        {
          'answer': '832f2396f78fac2ed0743bc82519fead',
          'choices': [
            'You had an unmatched parenthesis',
            'Your indentation mixed tabs and spaces',
            'You forgot a return statement',
            'You typed a variable name incorrectly'
          ],
          'hidden': False,
          'locked': True,
          'question': 'You get a SyntaxError. What is most likely to have happened?'
        },
        {
          'answer': '2c72c3de606e549372ac0e73251792ef',
          'choices': [
            'You had an unmatched parenthesis',
            'Your indentation mixed tabs and spaces',
            'You forgot a return statement',
            'You typed a variable name incorrectly'
          ],
          'hidden': False,
          'locked': True,
          'question': 'You get a IndentationError. What is most likely to have happened?'
        },
        {
          'answer': 'ec4242c5ebaee679569dc2c9792b63f4',
          'choices': [
            'You had an unmatched parenthesis',
            'Your indentation mixed tabs and spaces',
            'You forgot a return statement',
            'You typed a variable name incorrectly'
          ],
          'hidden': False,
          'locked': True,
          'question': 'You get a TypeError: blah blah blah NoneType blah blah blah. What is most likely to have happened?'
        },
        {
          'answer': 'a592eec1ed9a7a352c14e963522641b3',
          'choices': [
            'You had an unmatched parenthesis',
            'Your indentation mixed tabs and spaces',
            'You forgot a return statement',
            'You typed a variable name incorrectly'
          ],
          'hidden': False,
          'locked': True,
          'question': 'You get a NameError. What is most likely to have happened?'
        }
      ],
      'scored': False,
      'type': 'concept'
    }
  ]
}
