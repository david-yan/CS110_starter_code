def error_handler(string, num):
    """Tries the following:
    1. Converts the `string` parameter to an int.
    2. Divide the converted `string` with `num` and print the result

    - If the cast fails, print 'Cannot cast to int'
    - If the division causes an error, print 'Division failed'
    - If no error happens, print 'No errors'
    - At the very end, print 'Finished'

    >>> error_handler('not an int', 2)
    Cannot cast to int
    Finished
    >>> error_handler('1', 0)
    Division failed
    Finished
    >>> error_handler('1', 2)
    0.5
    No errors
    Finished
    """
    "*** YOUR CODE HERE ***"

def histogram_buckets(lst, size):
    """Creates a histogram from a list of integers where the bucket size
    is specified by the `size` parameter. Buckets start at 0. The key for
    the histogram is the beginning of the bucket, and the value is the number
    of items in the bucket.

    >>> histogram_buckets([3, 2, 5, 1, 4, 0, 1], 2)
    {2: 2, 4: 2, 0: 3}
    >>> histogram_buckets([5, 11, 23, 15, 24, 39, 12, 4, 17], 10)
    {0: 2, 10: 4, 20: 2, 30: 1}
    """
    "*** YOUR CODE HERE ***"
