test = {
  'name': 'What would Python print?',
  'points': 3,
  'suites': [
    {
      'cases': [
        {
          'answer': "<class 'str'>",
          'choices': [
            "<class 'int'>",
            "<class 'str'>",
            '5',
            "NameError: name 'x' is not defined"
          ],
          'hidden': False,
          'locked': False,
          'question': r"""
          Given the following block of code and user input, What would Python print?
          
          test.py:
          x = input('Enter integer: ')
          type(x)
          
          Command line:
          % python3 test.py
          Enter integer: 5
          ____
          """
        },
        {
          'answer': 'TypeError: can only concatenate str (not "int") to str',
          'choices': [
            '5',
            '6',
            '4',
            'TypeError: can only concatenate str (not "int") to str',
            "NameError: name 'x' is not defined"
          ],
          'hidden': False,
          'locked': False,
          'question': r"""
          Given the following block of code and user input, What would Python print?
          
          test.py:
          x = input('Enter integer: ')
          print(x + 1)
          
          Command line:
          % python3 test.py
          Enter integer: 5
          ____
          """
        },
        {
          'answer': '6',
          'choices': [
            '5',
            '6',
            '4',
            'TypeError: can only concatenate str (not "int") to str',
            "NameError: name 'x' is not defined"
          ],
          'hidden': False,
          'locked': False,
          'question': r"""
          Given the following block of code and user input, What would Python print?
          
          test.py:
          x = int(input('Enter integer: '))
          print(x + 1)
          
          Command line:
          % python3 test.py
          Enter integer: 5
          ____
          """
        }
      ],
      'scored': True,
      'type': 'concept'
    }
  ]
}
