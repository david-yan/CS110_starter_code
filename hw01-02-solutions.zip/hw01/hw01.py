""" Homework 1: If statements, Lists """

def both_positives(a, b):
    """Returns True if both a and b are positive.

    >>> both_positives(-1, 1)
    False
    >>> both_positives(1, 1)
    True
    >>> both_positives(0, 1)
    True
    """
    if a >= 0 and b >= 0:
        return True
    return False

def get_item(lst, n):
    """ Returns the nth element of the lst, or None if the element doesn't exist.

    >>> get_item([17, 73, 35, 97], 1)
    17
    >>> get_item('uniqlo', 4)
    'q'
    >>> get_item([1, 2, 3, 4], 5)
    >>> get_item([1, 2, 3, 4], -1)
    """
    if n < 1 or n > len(lst): # <--- Change here.
        return None
    output = lst[n - 1] # <--- Change here.
    return output

def if_function(condition, true_result, false_result):
    """Return true_result if condition is a true value, and false_result otherwise.

    >>> if_function(True, 2, 3)
    2
    >>> if_function(False, 2, 3)
    3
    >>> if_function(3==2, 3+2, 3-2)
    1
    >>> if_function(3>2, 3+2, 3-2)
    5
    """
    if condition:
        return true_result
    return false_result
