""" Homework 1 Review Week 1 """

def positive():
    """Ask if for an integer via the `input` command.
       Return True if the integer is positive, False otherwise.

    Example test cases:
    % python hw01_review.py
    Enter integer: 1
    True
    % python hw01_review.py
    Enter integer: -1
    False
    % python hw01_review.py
    Enter integer: 0
    True
    """
    if int(input("Enter number: ")) >= 0:
        return True
    return False

print(positive())
