""" Homework 2: Loops, Functions """

def reverse(string):
    """ Reverse a string without using the reversed string function.

    >>> reverse('abc')
    'cba'
    >>> reverse('a')
    'a'
    >>> reverse('')
    ''
    """
    output = ""
    for i in range(len(string)):
        # i = [0, 1, ..., len(lst)-1]
        # i * -1 = [0, -1, ..., -len(lst)+1]
        # -i + len(lst)-1 = [len(lst)-1, len(lst)-2, ..., 0]
        # want:             [len(lst)-1, len(lst)-2, ..., 0]
        index = len(string) - 1 - i
        output += string[index]
        # output = output + string[index]
        # string = 'abc'
        # output = "" + 'c'
        # output = 'c' + 'b'
        # output ='cb' + 'a'
    return output

"""
    output = ""
    for letter in string:
        output = string + output
        # string = 'abc'
        # output = 'a' + ''
        # output = 'b' + 'a'
        # output = 'c' + 'ba'

    return output
"""
def palindrome(string):
    """ Returns True if string is a palindrome.
        * Hint: Use the reverse function you wrote above.

    >>> palindrome('aba')
    True
    >>> palindrome('detartrated')
    True
    >>> palindrome('abc')
    False
    >>> palindrome('')
    True
    """
    return reverse(string) == string

def every_other(lst, n):
    """ Returns the result of combining every nth item of lst.

    >>> every_other([1, 2, 3, 4, 5, 6], 2)
    [1, 3, 5]
    >>> every_other([1, 2, 3, 4, 5], 2)
    [1, 3, 5]
    >>> every_other([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 3)
    [1, 4, 7, 10]
    """
    output = []
    for i in range(0, len(lst), n):
        # range(a, b, c) -> [a, b) w/ step size c
        output.append(lst[i])
        # output += lst[i]
        # expands to:
        # output = output + lst[i]
    return output
