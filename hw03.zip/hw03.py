def create_item(name, price):
    """Create and return an item as a dict instead of a list. The key, 'name' should
    be mapped to the name of the item, and the key, 'price' should be mapped
    to the price.

    >>> create_item('Zoom.us', 750)
    {'name': 'Zoom.us', 'price': 750}
    """
    "*** YOUR CODE HERE ***"

def get_value(d, key):
    """Get the value of the specified key in dict, d.

    >>> d = {'key1': 'val1', 'key2': 'val2'}
    >>> get_value(d, 'key2')
    'val2'
    """
    "*** YOUR CODE HERE ***"


def histogram(lst):
    """Given a list, return a dictionary in histogram format where the
    keys are each unique element in the list, and the value is the number
    of times that element appears in the list.

    >>> histogram([1, 1, 2, 3, 3, 1])
    {1: 3, 2: 1, 3: 2}
    >>> histogram([1, 'a', 'a'])
    {1: 1, 'a': 2}
    """
    "*** YOUR CODE HERE ***"

