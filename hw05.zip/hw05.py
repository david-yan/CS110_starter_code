def read_all(filename):
    """Opens the file with filename, prints it's contents, and
    closes the file.

    >>> read_all('test_file1')
    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin eget.
    """
    "*** YOUR CODE HERE ***"

def read_all_with(filename):
    """Opens the file with filename, prints it's contents, and
    closes the file, using the `with` method described in class.

    >>> read_all('test_file1')
    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin eget.
    """
    "*** YOUR CODE HERE ***"

def readline_n(filename, n):
	"""Reads and returns the nth line in the file, filename.

	>>> readline_n('test_file2', 3)
	\'Nullam dapibus elit quis enim porta, et feugiat purus maximus.\\n\'
	>>> readline_n('test_file2', 2)
	\'Proin ut ex sed diam tempor laoreet eu et eros.\\n\'
	"""
	"*** YOUR CODE HERE ***"
