test = {
  'name': 'Veritasiness',
  'points': 0,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> True and 13
          e5167090c56472bcf21f15693c3e9586
          # locked
          >>> False or 0
          76cbba351527b70f989d9c4d5e106ec2
          # locked
          >>> not 10
          76cbba351527b70f989d9c4d5e106ec2
          # locked
          >>> not None
          637d738397167fedce3e81e72ea29d20
          # locked
          """,
          'hidden': False,
          'locked': True
        },
        {
          'code': r"""
          >>> True and 1 / 0 and False  # If this errors, just type Error.
          77ffd5b9a6ed8de311945a103f92c814
          # locked
          >>> True or 1 / 0 or False  # If this errors, just type Error.
          637d738397167fedce3e81e72ea29d20
          # locked
          >>> True and 0  # If this errors, just type Error.
          1ebd420c83a0061548765e6afe17221d
          # locked
          >>> False or 1  # If this errors, just type Error.
          76cbba351527b70f989d9c4d5e106ec2
          # locked
          >>> 1 and 3 and 6 and 10 and 15  # If this errors, just type Error.
          19249aee01998179ce2baa7e35636b95
          # locked
          >>> 0 or False or 2 or 1 / 0  # If this errors, just type Error.
          e5e11c5709a034627f8995d0b5bac15c
          # locked
          """,
          'hidden': False,
          'locked': True
        }
      ],
      'scored': False,
      'type': 'wwpp'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> not 0
          637d738397167fedce3e81e72ea29d20
          # locked
          >>> (1 + 1) and 1  # If this errors, just type Error. If this is blank, just type Nothing.
          63f273cb0bfb82a1a4810bdbcdfbcf7d
          # locked
          >>> 1/0 or True  # If this errors, just type Error. If this is blank, just type Nothing.
          77ffd5b9a6ed8de311945a103f92c814
          # locked
          >>> (True or False) and False  # If this errors, just type Error. If this is blank, just type Nothing.
          76cbba351527b70f989d9c4d5e106ec2
          # locked
          """,
          'hidden': False,
          'locked': True
        }
      ],
      'scored': False,
      'type': 'wwpp'
    }
  ]
}
