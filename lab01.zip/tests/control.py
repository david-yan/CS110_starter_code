test = {
  'name': 'Control',
  'points': 0,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> def xk(c, d):
          ...     if c == 4:
          ...         return 6
          ...     elif d >= 4:
          ...         return 6 + 7 + c
          ...     else:
          ...         return 25
          >>> xk(10, 10)
          a799615418a6f4501ad544e13806a562
          # locked
          >>> xk(10, 6)
          a799615418a6f4501ad544e13806a562
          # locked
          >>> xk(4, 6)
          dec12663f9c55de3a6af4f37f7906f7d
          # locked
          >>> xk(0, 0)
          56eec9fe30bee046d0f7ad12b7ef6710
          # locked
          """,
          'hidden': False,
          'locked': True
        },
        {
          'code': r"""
          >>> def how_big(x):
          ...     if x > 10:
          ...         print('huge')
          ...     elif x > 5:
          ...         return 'big'
          ...     elif x > 0:
          ...         print('small')
          ...     else:
          ...         print("nothin'")
          >>> how_big(7)
          big
          # locked
          >>> how_big(12)
          huge
          # locked
          >>> how_big(1)
          small
          # locked
          >>> how_big(-1)
          nothin
          # locked
          """,
          'hidden': False,
          'locked': True
        }
      ],
      'scored': False,
      'type': 'wwpp'
    }
  ]
}
