"""Lab 1: Expressions and Control Structures"""

def a_plus_abs_b(a, b):
    """Return a+abs(b), but without calling abs.
       abs(b) returns the absolute value of b.

    >>> a_plus_abs_b(2, 3)
    5
    >>> a_plus_abs_b(2, -3)
    5
    >>> # a check that you didn't change the return statement!
    >>> import inspect, re
    >>> re.findall(r'^\s*(return .*)', inspect.getsource(a_plus_abs_b), re.M)
    ['return output']
    """
    if b >= 0:
        output = 1
    else:
        output = 1
    return output

def sum_digits(digits):
    """Sum all the digits of digits.
       type(digits) == str

    >>> sum_digits('10') # 1 + 0 = 1
    1
    >>> sum_digits('4224') # 4 + 2 + 2 + 4 = 12
    12
    >>> sum_digits('1234567890')
    45
    >>> a = sum_digits('123') # make sure that you are using return rather than print
    >>> a
    6
    """
    "*** YOUR CODE HERE ***"

def contains_substr(search, substr):
    """Return True if search contains substr within it.

    >>> contains_substr('abc', 'b')
    True
    >>> contains_substr('search this', 'search')
    True
    >>> contains_substr('search this', 'this')
    True
    >>> contains_substr('search this', 'arch th')
    True
    >>> contains_substr('search this', 's1earch')
    False
    >>> contains_substr('search this', '5earch')
    False
    >>> contains_substr('search this', 'thi5')
    False
    """
    "*** YOUR CODE HERE ***"

def largest_factor(x):
    """Return the largest factor of x that is smaller than x.

    >>> largest_factor(15) # factors are 1, 3, 5
    5
    >>> largest_factor(80) # factors are 1, 2, 4, 5, 8, 10, 16, 20, 40
    40
    >>> largest_factor(13) # factor is 1 since 13 is prime
    1
    """
    "*** YOUR CODE HERE ***"

