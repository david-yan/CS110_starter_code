""" Lab 1: Extra credit """

from operator import add, sub

def a_plus_abs_b_extra(a, b):
    """Return a+abs(b), but without calling abs.

    >>> a_plus_abs_b_extra(2, 3)
    5
    >>> a_plus_abs_b_extra(2, -3)
    5
    >>> # a check that you didn't change the return statement!
    >>> import inspect, re
    >>> re.findall(r'^\s*(return .*)', inspect.getsource(a_plus_abs_b), re.M)
    ['return h(a, b)']
    """
    if b >= 0:
        h = _____
    else:
        h = _____
    return h(a, b)


def hailstone(x):
    """Print the hailstone sequence starting at x and return its
    length.

    >>> a = hailstone(10)
    10
    5
    16
    8
    4
    2
    1
    >>> a
    7
    """
    "*** YOUR CODE HERE ***"
