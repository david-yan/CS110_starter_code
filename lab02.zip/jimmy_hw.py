"""Jimmy's Homework"""

def both_positives(a, b)
    """Returns True if both a and b are positive.

    >>> both_positives(-1, 1)
    False
    >>> both_positives(1, 1)
    True
    >>> both_positives(0, 1)
    True
    """
return a >= 0 and b >= 0

def a_plus_abs_b a, b:
    """Return a+abs(b), but without calling abs.
       abs(b) returns the absolute value of b.

    >>> a_plus_abs_b(2, 3)
    5
    >>> a_plus_abs_b(2, -3)
    5
    """
if b >= 0
output = a + b
else
output = a - b
return output

def add_two(number)
    """Adds two to the number, and then returns the string:
       'Two added to <number> is <number + 2>.'

    >>> add_two(1)
    Two added to 1 is 3.
    >>> add_two(100)
    Two added to 100 is 102.
    """
return print("Two added to " + number + " is " + number + 2 + ".")

