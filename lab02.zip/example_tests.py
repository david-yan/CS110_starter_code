def circumference(radius):
    pi = 3.1415926535
    return 2 * radius * pi

def area(radius):
    pi = 3.1415926535
    return radius ** 2 * pi


"""***************TESTS***************"""

print(circumference(5))
# Expecting 31.415926535
print(circumference(7))
# Expecting 43.982297149000004

print(area(5))
# Expecting 78.5398163375
print(area(7))
# Expecting 153.9380400215
